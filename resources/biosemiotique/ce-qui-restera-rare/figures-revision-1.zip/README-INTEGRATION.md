# Figures — assurance des modèles

Les six SVG sont conçus pour la charte de **Conscience Morte** et utilisent les variables déjà définies dans `assets/main.scss` :

`--paper`, `--paper-deep`, `--ink`, `--graphite`, `--line`, `--oxide`, `--moss`, `--blue`.

## Intégration recommandée

Copier les SVG dans :

```text
_includes/figures/
```

Puis les inclure en ligne dans l'article :

```html
<figure class="cm-figure cm-plate">
  {% include figures/03-chaine-cognitive.svg %}
  <figcaption>03 — La chaîne d’approvisionnement cognitive : transformations déclarées et héritage effectif.</figcaption>
</figure>
```

L'inclusion en ligne est importante : elle permet aux SVG d'hériter des variables CSS et de suivre le sélecteur clair/sombre du site.

## SCSS complémentaire

```scss
.cm-plate svg {
  display: block;
  width: 100%;
  height: auto;
  overflow: visible;
}

.cm-plate svg path,
.cm-plate svg line,
.cm-plate svg circle,
.cm-plate svg rect {
  vector-effect: non-scaling-stroke;
}
```

Le SCSS existant ajoute déjà `FIG. ` avant chaque légende. La légende doit donc commencer directement par son numéro (`03 — …`) et non par `Fig. 03`.

## Ordre et emplacement

1. `01-economie-frontiere.svg` — après le deuxième paragraphe de l'introduction.
2. `02-concentration-sillage.svg` — après « La frontière se concentre ; son sillage prolifère. »
3. `03-chaine-cognitive.svg` — après l'énumération des sept maillons.
4. `04-regime-assurance.svg` — après le premier paragraphe de la section sur le régime d'assurance.
5. `05-apprentissage-subliminal.svg` — après la description de l'expérience canonique.
6. `06-audit-aveugle.svg` — après la présentation de l'exercice d'audit à l'aveugle.

## Sources à créditer dans les légendes

- Figure 01 : graphique de l'auteur à partir de Cottier et al., *The Rising Costs of Training Frontier AI Models*, et du *AI Index Report 2025*.
- Figure 05 : adapté de Cloud et al., *Subliminal Learning*.
- Figure 06 : adapté de Marks, Treutlein et al., *Auditing Language Models for Hidden Objectives*.

Les figures 02, 03 et 04 sont originales.
